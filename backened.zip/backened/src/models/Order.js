const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Order = sequelize.define('Order', {
  productId: DataTypes.INTEGER,
  userId: DataTypes.INTEGER,
  farmerId: DataTypes.INTEGER,
  quantity: DataTypes.INTEGER,
  totalPrice: DataTypes.FLOAT
});

module.exports = Order;
