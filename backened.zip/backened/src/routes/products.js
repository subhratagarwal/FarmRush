const express = require('express');
const multer = require('multer');
const Product = require('../models/product');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

router.post('/', upload.single('image'), async (req,res)=>{
  const { name,price,farmerId } = req.body;
  const product = await Product.create({ name,price,image:req.file.filename,farmerId });
  res.json(product);
});

router.get('/', async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (err) {
    console.error('❌ Sequelize Error Message:', err.message);
    console.error('❌ Full Error Object:', err);
    res.status(500).send('Server error');
  }
});


module.exports = router;
