import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import FarmerDashboard from "./pages/FarmerDashboard";
import FarmerOrders from "./pages/FarmerOrders";
import Marketplace from "./pages/Marketplace";
import Cart from "./pages/Cart";
import OrderSummary from "./pages/OrderSummary";

export default function App() {
  const role = localStorage.getItem("role");

  return (
    <>
      <Navbar />
      <Routes>
        {!role && (
          <>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </>
        )}
        {role === "consumer" && (
          <>
            <Route path="/" element={<Marketplace />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/order-summary" element={<OrderSummary />} />
          </>
        )}
        {role === "farmer" && (
          <>
            <Route path="/" element={<FarmerDashboard />} />
            <Route path="/dashboard" element={<FarmerDashboard />} />
            <Route path="/farmer-orders" element={<FarmerOrders />} />
          </>
        )}
      </Routes>
    </>
  );
}
