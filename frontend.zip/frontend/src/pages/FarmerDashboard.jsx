import { useState } from "react";
import axios from "axios";

export default function FarmerDashboard() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();
    form.append("name", name);
    form.append("price", price);
    form.append("image", image);
    await axios.post("http://localhost:5000/api/products", form, {
      headers: { "Content-Type": "multipart/form-data" }
    });
    alert("✅ Product uploaded!");
  };

  return (
    <div className="p-6 max-w-xl mx-auto mt-10">
      <h2 className="text-3xl font-bold text-green-800 mb-6">Upload Product</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input className="border p-2 rounded w-full" placeholder="Product Name" onChange={(e) => setName(e.target.value)} />
        <input className="border p-2 rounded w-full" placeholder="Price per kg" onChange={(e) => setPrice(e.target.value)} />
        <input type="file" onChange={(e) => setImage(e.target.files[0])} />
        <button className="bg-green-700 text-white px-4 py-2 rounded">Upload</button>
      </form>
    </div>
  );
}
