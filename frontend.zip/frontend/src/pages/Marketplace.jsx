import { useEffect, useState } from "react";
import axios from "axios";

export default function Marketplace() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/products").then((res) => setProducts(res.data));
  }, []);

  const addToCart = (product, qty) => {
    if (!qty || qty <= 0) return;
    const totalPrice = qty * product.price;
    const brokerageFarmer = totalPrice * 0.02; // 2% brokerage
    const brokerageCustomer = totalPrice * 0.02;
    setCart((prev) => [
      ...prev,
      { ...product, quantity: qty, totalPrice, brokerageFarmer, brokerageCustomer },
    ]);
  };

  const placeOrder = async () => {
    try {
      for (const item of cart) {
        await axios.post("http://localhost:5000/api/orders", {
          productName: item.name,
          quantity: item.quantity,
          pricePerKg: item.price,
          totalPrice: item.totalPrice,
          brokerageFarmer: item.brokerageFarmer,
          brokerageCustomer: item.brokerageCustomer,
          customerName: "John Doe", // replace with logged-in user info
          customerContact: "9999999999",
        });
      }
      alert("✅ Order placed successfully!");
      setCart([]);
    } catch (err) {
      alert("❌ Failed to place order");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold mb-4">🛒 Marketplace</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((p) => {
          let qty = 0;
          return (
            <div key={p.id} className="border rounded p-4 shadow">
              <img
                src={`http://localhost:5000/uploads/${p.image}`}
                alt={p.name}
                className="h-40 w-full object-cover rounded mb-2"
              />
              <h3 className="text-xl font-semibold">{p.name}</h3>
              <p className="text-green-700 font-bold">₹{p.price} / kg</p>
              <input
                type="number"
                min="1"
                className="border p-1 rounded w-full my-2"
                placeholder="Quantity (kg)"
                onChange={(e) => (qty = e.target.value)}
              />
              <button
                className="bg-blue-600 text-white px-3 py-1 rounded"
                onClick={() => addToCart(p, qty)}
              >
                Add to Cart
              </button>
            </div>
          );
        })}
      </div>

      {cart.length > 0 && (
        <div className="mt-6 p-4 border rounded bg-gray-50">
          <h3 className="text-xl font-bold mb-2">🧾 Cart Summary</h3>
          {cart.map((item, idx) => (
            <div key={idx} className="border-b py-2">
              {item.name} - {item.quantity} kg → ₹{item.totalPrice}  
              <span className="text-sm text-gray-500">
                (Farmer brokerage ₹{item.brokerageFarmer}, Customer brokerage ₹{item.brokerageCustomer})
              </span>
            </div>
          ))}
          <button
            onClick={placeOrder}
            className="mt-4 bg-green-700 text-white px-4 py-2 rounded"
          >
            Place Order
          </button>
        </div>
      )}
    </div>
  );
}
