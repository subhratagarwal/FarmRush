import { useEffect, useState } from "react";
import axios from "axios";

export default function Orders() {
  const [products, setProducts] = useState([]);
  const [quantities, setQuantities] = useState({});

  const fetchProducts = async () => {
    const res = await axios.get("http://localhost:5000/api/products");
    setProducts(res.data);
  };

  const handleOrder = async (productId) => {
    const qty = quantities[productId] || 1;
    await axios.post("http://localhost:5000/api/products/order", {
      productId,
      quantity: qty,
    });
    alert("✅ Order placed successfully!");
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="p-6 bg-green-50 min-h-screen">
      <h1 className="text-3xl font-bold mb-6">🛒 Marketplace</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((p) => (
          <div key={p.id} className="border rounded-lg p-4 bg-white shadow">
            <img src={p.image} alt={p.name} className="h-32 w-full object-cover mb-2 rounded" />
            <h3 className="font-bold text-lg">{p.name}</h3>
            <p className="text-green-700 font-medium">₹{p.price} per kg</p>
            <input
              type="number"
              min="1"
              className="border p-1 rounded w-full mt-2"
              value={quantities[p.id] || ""}
              onChange={(e) =>
                setQuantities({ ...quantities, [p.id]: e.target.value })
              }
            />
            <button
              onClick={() => handleOrder(p.id)}
              className="bg-green-600 text-white py-1 px-3 mt-2 rounded hover:bg-green-700 w-full"
            >
              Place Order
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
