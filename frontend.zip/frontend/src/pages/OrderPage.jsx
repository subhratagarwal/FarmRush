import { useParams } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

export default function OrderPage() {
  const { id } = useParams();
  const [quantity, setQuantity] = useState(1);

  const handleOrder = async () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return alert("Please login first!");

    const total = quantity * 100; // sample logic; ideally fetch price from product
    const brokerage = total * 0.05; // 5% platform commission

    try {
      await axios.post("http://localhost:5000/api/orders", {
        productId: id,
        userId: user.id,
        quantity,
        totalPrice: total,
        brokerage
      });
      alert(`✅ Order placed! Total: ₹${total} (incl. brokerage ₹${brokerage})`);
    } catch {
      alert("❌ Order failed");
    }
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-4">📦 Place Order</h2>
      <input
        type="number"
        className="border p-2 rounded w-full mb-4"
        placeholder="Quantity (kg)"
        onChange={(e) => setQuantity(e.target.value)}
      />
      <button onClick={handleOrder} className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
        Confirm Order
      </button>
    </div>
  );
}
