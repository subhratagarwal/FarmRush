import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Cart({ cartItems, setCartItems }) {
  const navigate = useNavigate();

  const totalWithoutBrokerage = cartItems.reduce((acc, item) => acc + item.price * item.qty, 0);
  const brokerageFarmer = totalWithoutBrokerage * 0.05;   // 5% farmer side
  const brokerageCustomer = totalWithoutBrokerage * 0.05; // 5% customer side
  const grandTotal = totalWithoutBrokerage + brokerageCustomer;

  const placeOrder = async () => {
    for (const item of cartItems) {
      await axios.post("http://localhost:5000/api/orders", {
        productName: item.name,
        quantity: item.qty,
        pricePerKg: item.price,
        totalPrice: item.qty * item.price,
        brokerageFarmer,
        brokerageCustomer,
        customerName: "Demo User",        // Replace with logged-in user
        customerContact: "9999999999"     // Replace with logged-in user contact
      });
    }
    setCartItems([]);
    navigate("/order-summary", { state: { cartItems, grandTotal, brokerageFarmer, brokerageCustomer } });
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">🛒 Your Cart</h1>
      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <ul className="space-y-2 mb-4">
            {cartItems.map((item, idx) => (
              <li key={idx} className="flex justify-between border-b py-2">
                <span>{item.name} ({item.qty}kg)</span>
                <span>₹{item.price * item.qty}</span>
              </li>
            ))}
          </ul>
          <p className="font-semibold">Subtotal: ₹{totalWithoutBrokerage}</p>
          <p>Brokerage (Farmer): ₹{brokerageFarmer}</p>
          <p>Brokerage (You): ₹{brokerageCustomer}</p>
          <p className="text-lg font-bold mt-2">Grand Total: ₹{grandTotal}</p>
          <button
            onClick={placeOrder}
            className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
          >
            ✅ Place Order
          </button>
        </>
      )}
    </div>
  );
}
