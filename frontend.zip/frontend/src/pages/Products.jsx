import { useEffect, useState } from "react";

export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // 🔧 Fetch products from backend
    fetch("http://localhost:5000/api/products")
      .then((res) => res.json())
      .then(setProducts);
  }, []);

  return (
    <div>
      <h2 className="text-3xl font-bold text-green-900 mb-6">Available Products</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {products.map((p) => (
          <div key={p.id} className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-xl font-semibold">{p.name}</h3>
            <p className="text-gray-700">Price: ₹{p.price} / {p.unit}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
