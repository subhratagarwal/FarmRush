import { Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const role = localStorage.getItem("role");
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
  };

  return (
    <nav className="bg-green-700 text-white p-4 flex justify-between">
      <div className="flex gap-4">
        <Link to="/" className="font-bold text-lg">🌾 FarmerApp</Link>
        {role === "consumer" && (
          <>
            <Link to="/" className="hover:underline">Marketplace</Link>
            <Link to="/cart" className="hover:underline">Cart</Link>
            <Link to="/order-summary" className="hover:underline">My Orders</Link>
          </>
        )}
        {role === "farmer" && (
          <>
            <Link to="/dashboard" className="hover:underline">Dashboard</Link>
            <Link to="/farmer-orders" className="hover:underline">Orders</Link>
          </>
        )}
      </div>
      <div className="flex gap-4">
        {!role && <Link to="/login" className="hover:underline">Login</Link>}
        {!role && <Link to="/register" className="hover:underline">Register</Link>}
        {role && <button onClick={logout} className="hover:underline">Logout</button>}
      </div>
    </nav>
  );
}
