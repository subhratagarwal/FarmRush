import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import FarmerDashboard from "./pages/FarmerDashboard";
import Marketplace from "./pages/Marketplace";
import Cart from "./pages/Cart";
import BillSummary from "./pages/BillSummary";
import Stock from "./pages/Stock";

// 🔒 simple ProtectedRoute wrapper
function ProtectedRoute({ children, role }) {
  const token = localStorage.getItem("token");
  const userRole = localStorage.getItem("role");
  if (!token) return <Navigate to="/login" />;
  if (role && userRole !== role) return <Navigate to="/" />;
  return children;
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* ✅ Consumer marketplace/cart/bill */}
        <Route
          path="/marketplace"
          element={
            <ProtectedRoute role="customer">
              <Marketplace />
            </ProtectedRoute>
          }
        />
        <Route
          path="/cart"
          element={
            <ProtectedRoute role="customer">
              <Cart />
            </ProtectedRoute>
          }
        />
        <Route
          path="/bill"
          element={
            <ProtectedRoute role="customer">
              <BillSummary />
            </ProtectedRoute>
          }
        />

        {/* ✅ Farmer routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute role="farmer">
              <FarmerDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/stock"
          element={
            <ProtectedRoute role="farmer">
              <Stock />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}
