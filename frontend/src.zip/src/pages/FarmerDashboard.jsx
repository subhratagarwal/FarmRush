// src/pages/FarmerDashboard.jsx
import { useState, useEffect } from "react";
import axios from "axios";

export default function FarmerDashboard() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState(null);
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await axios.get("http://localhost:5000/api/orders/farmer");
    setOrders(res.data);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const farmerId = 1; // replace with actual logged-in farmer id
    const form = new FormData();
    form.append("name", name);
    form.append("price", price);
    form.append("image", image);
    form.append("farmerId", farmerId);
    await axios.post("http://localhost:5000/api/products", form, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    alert("✅ Product uploaded!");
  };

  const handleStatus = async (id, status) => {
    await axios.put(`http://localhost:5000/api/orders/${id}`, { status });
    fetchOrders();
  };

  return (
    <div className="p-6 space-y-8">
      <div className="max-w-xl mx-auto">
        <h2 className="text-3xl font-bold text-green-800 mb-4">Upload Product</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            className="border p-2 rounded w-full"
            placeholder="Product Name"
            onChange={(e) => setName(e.target.value)}
          />
          <input
            className="border p-2 rounded w-full"
            placeholder="Price per kg"
            onChange={(e) => setPrice(e.target.value)}
          />
          <input type="file" onChange={(e) => setImage(e.target.files[0])} />
          <button className="bg-green-700 text-white px-4 py-2 rounded">
            Upload
          </button>
        </form>
      </div>

      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-green-800 mb-4">Incoming Orders</h2>
        {orders.map((order) => (
          <div
            key={order.id}
            className="border rounded p-4 mb-3 flex justify-between items-center"
          >
            <div>
              <p className="font-semibold">{order.productName}</p>
              <p>Qty: {order.quantity}</p>
              <p>Total: ₹{order.totalPrice}</p>
              <p>Brokerage (Farmer): ₹{order.brokerageFarmer}</p>
              <p>Status: {order.status}</p>
            </div>
            {order.status === "Pending" && (
              <div className="space-x-2">
                <button
                  onClick={() => handleStatus(order.id, "Accepted")}
                  className="bg-green-600 text-white px-3 py-1 rounded"
                >
                  Accept
                </button>
                <button
                  onClick={() => handleStatus(order.id, "Declined")}
                  className="bg-red-600 text-white px-3 py-1 rounded"
                >
                  Decline
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
