import { useEffect, useState } from "react";
import axios from "axios";

export default function FarmerOrders() {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await axios.get("http://localhost:5000/api/orders/farmer");
    setOrders(res.data);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateStatus = async (id, status) => {
    await axios.put(`http://localhost:5000/api/orders/${id}`, { status });
    fetchOrders();
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Incoming Orders</h2>
      <ul className="space-y-4">
        {orders.map(o => (
          <li key={o.id} className="border p-4 rounded">
            <p>📦 {o.productName} ({o.quantity} kg)</p>
            <p>💰 Total: ₹{o.totalPrice}</p>
            <p>👤 {o.customerName} ({o.customerContact})</p>
            <div className="mt-2 flex gap-2">
              <button onClick={()=>updateStatus(o.id,"Accepted")} className="bg-green-600 text-white px-3 py-1 rounded">Accept</button>
              <button onClick={()=>updateStatus(o.id,"Declined")} className="bg-red-600 text-white px-3 py-1 rounded">Decline</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
