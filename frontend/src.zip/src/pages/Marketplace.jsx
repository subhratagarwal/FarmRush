import { useEffect, useState } from "react";
import axios from "axios";

export default function Marketplace() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/products").then((res) => setProducts(res.data));
  }, []);

  const addToCart = (p, qty) => {
    if (qty <= 0) return;
    const item = {
      id: p.id,
      name: p.name,
      price: p.price,
      qty: Number(qty),
      farmerId: p.farmerId
    };
    setCart([...cart, item]);
  };

  const checkout = () => {
    localStorage.setItem("cart", JSON.stringify(cart));
    window.location.href = "/bill";
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-4">
      <h2 className="text-2xl font-bold mb-4">🛒 Marketplace</h2>
      {products.map((p) => {
        let qty = 0;
        return (
          <div
            key={p.id}
            className="border rounded-lg p-4 flex items-center justify-between shadow-sm"
          >
            <div>
              <h3 className="font-bold">{p.name}</h3>
              <p>₹ {p.price} per kg</p>
            </div>
            {p.image && (
              <img
                src={`http://localhost:5000/uploads/${p.image}`}
                alt={p.name}
                className="w-20 h-20 object-cover rounded"
              />
            )}
            <div className="flex flex-col gap-2">
              <input
                type="number"
                min="1"
                placeholder="Quantity (kg)"
                onChange={(e) => (qty = e.target.value)}
                className="border rounded p-1 w-24"
              />
              <button
                className="bg-green-600 text-white px-3 py-1 rounded"
                onClick={() => addToCart(p, qty)}
              >
                Add to Cart
              </button>
            </div>
          </div>
        );
      })}
      {cart.length > 0 && (
        <button
          onClick={checkout}
          className="bg-blue-700 text-white px-4 py-2 rounded mt-4"
        >
          Proceed to Bill Summary
        </button>
      )}
    </div>
  );
}
