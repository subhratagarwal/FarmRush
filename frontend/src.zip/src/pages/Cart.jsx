import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Cart() {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const c = JSON.parse(localStorage.getItem("cart") || "[]");
    setCart(c);
  }, []);

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const placeOrder = async () => {
    try {
      for (const item of cart) {
        await axios.post("http://localhost:5000/api/orders", {
          productName: item.name,
          quantity: item.quantity,
          pricePerKg: item.price,
          totalPrice: item.price * item.quantity,
          brokerageFarmer: (item.price * item.quantity) * 0.05,
          brokerageCustomer: (item.price * item.quantity) * 0.05,
          customerName: "Test User", // ideally from auth
          customerContact: "0000000000",
          status: "Pending",
        });
      }
      alert("✅ Order placed!");
      localStorage.removeItem("cart");
      navigate("/bill");
    } catch (err) {
      console.error(err);
      alert("❌ Failed to place order");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
      {cart.map((item, idx) => (
        <div key={idx} className="border p-2 rounded mb-2">
          <h3>{item.name}</h3>
          <p>Qty: {item.qty} kg</p>
          <p>Price: ₹{item.price}/kg</p>
          <p className="font-bold">Subtotal: ₹{item.price * item.quantity}</p>
        </div>
      ))}
      <h3 className="text-xl font-bold mt-4">Total: ₹{total}</h3>
      <button
        onClick={placeOrder}
        className="bg-green-700 text-white px-4 py-2 rounded mt-4"
      >
        Place Order
      </button>
    </div>
  );
}
