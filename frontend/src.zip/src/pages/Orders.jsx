import { useEffect, useState } from "react";
import axios from "axios";

export default function Orders() {
  const role = localStorage.getItem("role");
  const userId = localStorage.getItem("userId");
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const endpoint =
      role === "farmer"
        ? `http://localhost:5000/api/orders/farmer?farmerId=${userId}`
        : `http://localhost:5000/api/orders/customer?userId=${userId}`;
    try {
      const res = await axios.get(endpoint);
      setOrders(res.data);
    } catch (err) {
      console.error("Failed to fetch orders:", err);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleStatus = async (id, status) => {
    await axios.put(`http://localhost:5000/api/orders/${id}`, { status });
    fetchOrders();
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">
        {role === "farmer" ? "Incoming Orders" : "My Orders"}
      </h2>
      <div className="space-y-4">
        {orders.length === 0 ? (
          <p>No orders found.</p>
        ) : (
          orders.map((order) => (
            <div
              key={order.id}
              className="border rounded p-4 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center"
            >
              <div>
                <p className="font-semibold">{order.productName || "Product"}</p>
                <p>Quantity: {order.quantity} kg</p>
                <p>Total: ₹{order.totalPrice}</p>
                <p>Status: {order.status}</p>

                {role === "customer" && (
                  <p className="text-sm text-gray-600">
                    Brokerage (5%): ₹{(order.totalPrice * 0.05).toFixed(2)}
                  </p>
                )}
              </div>

              {role === "farmer" && order.status === "Pending" && (
                <div className="mt-2 md:mt-0 space-x-2">
                  <button
                    onClick={() => handleStatus(order.id, "Confirmed")}
                    className="bg-green-600 text-white px-3 py-1 rounded"
                  >
                    ✅ Accept
                  </button>
                  <button
                    onClick={() => handleStatus(order.id, "Declined")}
                    className="bg-red-600 text-white px-3 py-1 rounded"
                  >
                    ❌ Decline
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
