const express = require('express');
const multer = require('multer');
const Product = require('../models/product');
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

/**
 * 📌 Add new product
 */
router.post('/', upload.single('image'), async (req, res) => {
  try {
    const { name, price, farmerId } = req.body;
    const image = req.file ? req.file.filename : null;
    const product = await Product.create({ name, price, image, farmerId });
    res.json(product);
  } catch (err) {
    console.error('❌ Error creating product:', err);
    res.status(500).send('Server error while creating product.');
  }
});

/**
 * 📌 Get all products
 */
router.get('/', async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (err) {
    console.error('❌ Sequelize Error Message:', err.message);
    console.error('❌ Full Error Object:', err);
    res.status(500).send('Server error');
  }
});

/**
 * 📌 Update product details (name, price, image)
 */
// PUT update product
router.put('/:id', upload.single('image'), async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).send('Not found');

    if (req.body.name) prod.name = req.body.name;
    if (req.body.price) prod.price = req.body.price;
    if (req.file) prod.image = req.file.filename;

    await prod.save();
    res.json(prod);
  } catch (err) {
    console.error(err);
    res.status(500).send('Update failed');
  }
});


/**
 * 📌 Delete product
 */
router.delete('/:id', async (req, res) => {
  try {
    const prod = await Product.findByPk(req.params.id);
    if (!prod) return res.status(404).send('Product not found');

    await prod.destroy();
    res.json({ message: '✅ Product deleted successfully' });
  } catch (err) {
    console.error('❌ Error deleting product:', err);
    res.status(500).send('Delete failed');
  }
});

module.exports = router;
