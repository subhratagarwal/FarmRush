const express = require("express");
const router = express.Router();
const Order = require("../models/Order");

// POST new order
router.post("/", async (req, res) => {
  try {
    const order = await Order.create(req.body);
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to place order" });
  }
});

// GET orders for a customer using query param
router.get("/customer", async (req, res) => {
  try {
    const userId = req.query.userId;
    const orders = await Order.findAll({ where: { userId } });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// GET orders for a farmer using query param
router.get("/farmer", async (req, res) => {
  try {
    const farmerId = req.query.farmerId;
    const orders = await Order.findAll({ where: { farmerId } });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch farmer orders" });
  }
});

// Update order status
router.put("/:id", async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.id);
    if (!order) return res.status(404).json({ error: "Order not found" });
    order.status = req.body.status;
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: "Failed to update order" });
  }
});

module.exports = router;
