// backend/models/Order.js

const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Order = sequelize.define('Order', {
  productId: DataTypes.INTEGER,
  userId: DataTypes.INTEGER,
  farmerId: DataTypes.INTEGER,
  quantity: DataTypes.INTEGER,
  totalPrice: DataTypes.FLOAT,
  productName: DataTypes.STRING, // ✅ ADD THIS LINE
  status: {
    type: DataTypes.STRING,
    defaultValue: "Pending"
  }
});

module.exports = Order;
