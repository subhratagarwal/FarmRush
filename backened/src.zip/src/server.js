const express = require('express');
const cors = require('cors');
require('dotenv').config();
const sequelize = require('./config/db');
const path = require('path');

// Import routes (these also import the models)
const userRoutes = require('./routes/users');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);

// ✅ Sync database and automatically add missing columns
sequelize.sync({ alter: true })
  .then(() => console.log('✅ DB synced'))
  .catch(err => console.error('❌ Sync error:', err));

// ✅ Authenticate connection
sequelize.authenticate()
  .then(() => console.log('✅ DB connected'))
  .catch(err => console.error('❌ DB connection error:', err));

app.listen(5000, () => console.log('🚀 Backend on 5000'));
